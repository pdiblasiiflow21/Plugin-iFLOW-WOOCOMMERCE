<?php
/**
 * Box Sizes for fedex in array format
 */

return array(
	array(
		'name'       => 'Caja Ejemplo',
		'id'         => 'FEDEX_SMALL_BOX',
		'max_weight' => 50,
		'box_weight' => 0,
		'length'     => 12.375,
		'width'      => 10.875,
		'height'     => 1.5
	),
);