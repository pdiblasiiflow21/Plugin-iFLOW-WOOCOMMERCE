<?php

namespace iflow\iflow;

use DateTime;
use iflow\iflow\Helper;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class iflowConnector
{
    private $api_key, $api_secret, $account_id, $origin_id, $logger;
    public $credentials_checked;
    protected $last_error;

    const SOURCE_FOR_API = 'woocommerce@'.iflow_VERSION;


    public function __construct()
    {

        $this->api_key = get_option('iflow_api_key');
        $this->api_secret = get_option('iflow_api_secret');
        $this->account_id = get_option('iflow_account_id');
        $this->origin_id = get_option('iflow_origin_id');
        $this->logger = wc_get_logger();
        $this->credentials_checked = get_option('iflow_credentials_check');

    }

    public function get_api_key()
    {
        return $this->api_key;
    }

    public function get_api_secret()
    {
        return $this->api_secret;
    }

    public function get_account_id()
    {
        return $this->account_id;
    }

    public function get_origin_id()
    {
        return $this->origin_id;
    }


    /**
     * @param \WC_Order|null $order
     * @return false|mixed
     */
    public function create_shipment($order = null)
    {
      // aca deberia enviar a milonga
        if (!$order) {
            $this->last_error = 'Invalid order.';
            $this->logger->warning('Invalid order', unserialize(iflow_LOGGER_CONTEXT));
            return false;
        }

        if (!$this->credentials_checked) {
            $this->last_error = 'Invalid credentials.';
            $this->logger->warning('Invalid credentials', unserialize(iflow_LOGGER_CONTEXT));
            return false;
        }

        $helper = new Helper($order);
        $shipment_info = unserialize($order->get_meta('iflow_shipping_info', true));
        if (!isset($shipment_info['logistic_type'])) {
            $shipment_info['logistic_type'] = null;
        }

        // Prepare packages
        $products = $helper->get_items_from_order($order);

        // Create destination object
        $destination = $helper->get_destination_from_order($order);

        $declared_value_modifier = get_option('iflow_insurance_modifier', 100)/100;
        $declared_value = max(0, $order->get_subtotal() * $declared_value_modifier);

        $payload = array(
            'account_id' => $this->get_account_id(),
            'origin_id' => $this->get_origin_id(),
            'external_id' => 'W'.$order->get_id(),
            'source' => self::SOURCE_FOR_API,
            'declared_value' => round(floatval($declared_value),2),
            'items' => $products['items'],
            'destination' => $destination
        );

        if (!$payload['items'] || !$payload['destination']) {
            $this->logger->warning('No items or destination', unserialize(iflow_LOGGER_CONTEXT));
            return false;
        }

        if (!is_null($shipment_info['logistic_type'])) {
            $payload['logistic_type'] = $shipment_info['logistic_type'];

        } elseif (in_array(strval($this->origin_id), ['32', '2014'])) {
            $payload['logistic_type'] = 'fulfillment';
        }

        if (!is_null($shipment_info['carrier_id'])) {
            $payload['carrier_id'] = $shipment_info['carrier_id'];
        }

        if (!is_null($shipment_info['service_type'])) {
            $payload['service_type'] = $shipment_info['service_type'];
        } else {
            $payload['service_type'] = 'standard_delivery';
        }

        /*if ($payload['service_type'] == 'pickup_point' && isset($shipment_info['point_id'])) {
            $payload['destination']['point_id'] = $shipment_info['point_id'];
            unset(
                $payload['destination']['street'],
                $payload['destination']['street_number'],
                $payload['destination']['street_extras'],
                $payload['destination']['city'],
                $payload['destination']['state'],
                $payload['destination']['zipcode']
            );
        }*/
// aca debe obtiene los tipo de envios .
        if ($response = $this->call_api('POST', '/shipments', $payload)) {
            return json_decode($response['body'], true);
        }

        return false;

    }


    public function get_origins() // Por el momento el origen es Fijo.
    {

      /*
        if (!$this->credentials_checked) {
            return false;
        }

        if ($response = $this->call_api('GET', '/addresses', array('account_id' => $this->get_account_id()))) {
            $response = json_decode($response['body'], true);
            $new_addresses = array();

            foreach ($response['data'] as $address) {
                $new_address = $address;
                $new_address['id'] = $address['id'];
                $new_address['name'] = $address['name'];
                $new_address['address'] = $address['street'] . ' ' . $address['street_number'];
                $new_addresses[] = $new_address;
            }
            return $new_addresses;

        } else {
            return false;
        }
        */
        $new_addresses []= array(
          "id"=>'1',
          "name"=>'Casa',
         "address"=>'Sucre 878');
    }

    public function get_account() // sacar
    {
        if ($response = get_option('iflow_api_key') ) {
            return $response;

        } else {
            return false;
        }
    }

    public function get_shipment($shipment_id) // sacar
    {
      if ($response = get_option('iflow_api_key') ) {
          return $response;

      } else {
          return false;
      }
    }

    public function quote($destination, $packages = [], $items = [], $declared_value = 0, $service_types = null, $mix = null, $max_count = 1)
    {



            $quote_result = array();
            $quote_result['delivery_date'] = '18-10-2021';
            $quote_result['shipping_time'] = '19-10-2021';
            $quote_result['price'] = '999.99';
            $quote_result['code'] = 'iFLOW SA';
            $quote_result['result'] = 'ok';
            $quote_results[] = $quote_result;


            return $quote_results;

        } else {
            return false;
        }
    }

    // aca hace llamados a la API

    public function call_api($method = '', $endpoint = '', $params = array(), $headers = array())
    {

    // aca hacer llamado al auxiliar, traer el token y enviar a cotizar el envio.


    // original !!
        if ($method && $endpoint) {
            $headers['Content-Type'] = 'application/json';
            $headers['Accept'] = 'application/json';
            $headers['Authorization'] = 'Basic '.base64_encode($this->get_api_key().':'.$this->get_api_secret());

            $url = 'http://test-api.iflow21.com/api/';
            $args = array(
                'headers' => $headers,
                'timeout' => 15
            );

            if ($method === 'GET') {
                $url .= '?' . http_build_query($params);
                $response = wp_remote_get($url, $args);

            } elseif ($method === 'POST') {
                $args['body'] = json_encode($params);
                $response = wp_remote_post($url, $args);

            } else {
                $args['body'] = json_encode($params);
                $args['method'] = $method;
                $response = wp_remote_request($url, $args);
            }


            if (is_wp_error($response)) {
                // Request failed with local error
                $this->logger->error('Wordpress error: ' . $response->get_error_message(), unserialize(iflow_LOGGER_CONTEXT));
                return false;
            }

            if ($response['response']['code'] != 200 && $response['response']['code'] != 201) {
                if ($response['response']['code'] == 403) {
                    update_option('iflow_credentials_check',false);
                }
                // API Request failed
                $this->last_error = wc_print_r($response['body'], 1);
                $this->logger->error('Error '.$response['response']['code'].' calling '.$endpoint.' - Response: '.wc_print_r(json_encode($response), true).' with params: '.wc_print_r(json_encode($params), true), unserialize(iflow_LOGGER_CONTEXT));
                return false;

            } else {
                // Success
                return $response;
            }

        }
    }


    public function getLastError()
    {
        return $this->last_error;
    }
}
