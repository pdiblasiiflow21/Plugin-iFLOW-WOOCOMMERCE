<?php


namespace iflow\iflow;

use WC_Shipping_Method;

use iflow\iflow\aux_iflow;

use iflow\iflow\iflowConnector;

error_reporting(0);

if (!defined('ABSPATH')) {
    exit; 
    // Exit if accessed directly.
}

function iflow_init()
{
  if (!class_exists('WC_iflow')) {
          class WC_iflow extends WC_Shipping_Method

          {
            private $logger;
            public function __construct($instance_id = 0)
            {
               $this->id = 'iflow';
               $this->method_title = 'iFLOW eCOMMERCE S.A.';
               $this->method_description = 'Envíos con IFLOW S.A.';
               $this->title = 'Envío con IFLOW S.A.';
               $this->instance_id = absint($instance_id);
               $this->supports = array(
                   'shipping-zones',
                   'instance-settings',
                   'instance-settings-modal'
               );
               $this->logger = wc_get_logger();
               $this->init();
               add_action('woocommerce_update_options_shipping_iflow', array($this, 'process_admin_options'));
            }

            function init()
            {
                $this->form_fields = array();
                $this->instance_form_fields = array(
                        'service_types' => array(
                          'title' => __('Tipos de Servicio Habilitados', 'woocommerce'),
                          'description'=>'Selecciona los tipos de servicio que quieras ofrecer. Selecciona múltiples opciones manteniendo la tecla CTRL.',
                          'type' => 'multiselect',
                          'default' => array('standard_delivery','fulfillment_delivery'),
                          'options' => array(
                              'standard_delivery'    => 'Estandar by iFLOW SA',
                              'fulfillment_delivery' => 'Fulfillment By iFLOW SA'
                              
                            )
                    ),
                );
                
                $classes = WC()->shipping->get_shipping_classes();
                foreach ($classes as $class) {
                    $this->instance_form_fields['clase']['options'][$class->name] = $class->name;
                }
		            
            }


//aca debo cotizar yo
  public function calculate_shipping($package = array())
  {
      //var_dump (get_option('iflow_free_shipping_threshold'));
      
              // Prepare packages para enviar a cotizar

                $usrapi = get_option('iflow_api_key');
                $clvapi = get_option('iflow_api_secret');
                $products = $this->get_products_from_cart();
                
                $costo_ord  = WC()->cart->get_subtotal();
                $total_Peso = $produtos["shipping_info"]["total_weight"];
                $max_ancho  = 0;
                $max_Alto   = 0;
                $max_largo  = 0;

             

               
                foreach ($products["items"] as $key1 => $items) { 
                    
					if ($max_ancho < $items["width"] ) { $max_ancho = $items["width"]; } 

                    if  ($max_Alto < $items["height"] ) {$max_Alto = $items["height"];}

                    if  ($max_Alto < $items["length"] ) {$max_largo = $items["length"];}
                    
                }

                // evaluo si la direccion de envio y facturacion son diferentes.

                $shipping_address = [
                    'city' => WC()->customer->get_shipping_city(),
                    'state' => WC()->customer->get_shipping_state(),
                    'zipcode' => WC()->customer->get_shipping_postcode()
                ];

                $billing_address = [
                    'city' => WC()->customer->get_billing_city(),
                    'state' => WC()->customer->get_billing_state(),
                    'zipcode' => WC()->customer->get_billing_postcode()
                ];

                if (!empty($shipping_address['city']) && !empty($shipping_address['state']) && !empty($shipping_address['zipcode'])) {
                    $destination = $shipping_address;
                } else {
                    $destination = $billing_address;
                }

                $destination['zipcode'] = filter_var($destination['zipcode'], FILTER_SANITIZE_NUMBER_INT);
                $destination['state'] = Helper::get_state_name($destination['state']);



                $codigo_postal = $destination['zipcode'];
                $provincia = $destination['state'] ;
            
            //
            
            
            
            $cotizar["packages"][0]["width"]= $max_ancho;
            $cotizar["packages"][0]["height"]=$max_Alto;
            $cotizar["packages"][0]["length"]=$max_largo;
            $cotizar["packages"][0]["real_weight"]=$total_Peso;
            $cotizar["packages"][0]["gross_price"]=$costo_ord;
            $cotizar["zip_code"]=$codigo_postal;
            $cotizar["province"]=$provincia;
            $cotizar["delivery_mode"]= 1;
            

            $COTjson = json_encode($cotizar);


    /**********************************************************************************/
    /*  Obtengo el token de la api */
    /**********************************************************************************/

                    $URL = ("http://api.iflow21.com/api/login");

                    //echo ($url); 
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => "$URL",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS =>"{\"_username\":\"$usrapi\",\"_password\":\"$clvapi\"}",
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "Cookie: SERVERID=api_iflow21"
                    ),
                    ));

                    $response = curl_exec($curl);
                    curl_close($curl);
                    $arraypsd = json_decode($response,true);
                $tokeapi= $arraypsd["token"];

    /**********************************************************************************/
    /*  Envio a la Api los datos para cotizar
    /**********************************************************************************/
                        $URL = ("http://api.iflow21.com/api/rate");
                        $curl = curl_init();
                                    curl_setopt_array($curl, array(
                                        CURLOPT_URL => "$URL",
                                        CURLOPT_RETURNTRANSFER => true,
                                        CURLOPT_ENCODING => "",
                                        CURLOPT_MAXREDIRS => 10,
                                        CURLOPT_TIMEOUT => 0,
                                        CURLOPT_FOLLOWLOCATION => true,
                                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                        CURLOPT_CUSTOMREQUEST => "POST",
                                        CURLOPT_POSTFIELDS =>$COTjson,
                                        CURLOPT_HTTPHEADER => array(
                                        "Content-Type: application/json",
                                        "Authorization: Bearer $tokeapi",
                                        "Cookie: SERVERID=api_iflow21"
                                    ),
                                        ));

                                    $response = curl_exec($curl);
                                    curl_close($curl);
                                    $cotizado = json_decode($response, true);
                
                if (!empty(get_option('iflow_additional_charge', 0))) {
                    $additional_charge = true;
                } else {
                    $additional_charge = false;
                }                         
                    
                $use_free_shipping = false;
                //var_dump(get_option('iflow_free_shipping_threshold'));
        
                        if (get_option('iflow_free_shipping_threshold')) {
                            if (WC()->cart->get_subtotal() >= floatval(get_option('iflow_free_shipping_threshold'))) {
                                $use_free_shipping = true;
                            }

                            
                            if (!empty(get_option('iflow_additional_charge', 0))) {
                                $additional_charge = true;
                            } else {
                                $additional_charge = false;
                            }


                                }

            $cost = (isset($cotizado["results"]["shipping_cost"])? $cotizado["results"]["shipping_cost"] : 500);
                            

                            if ($use_free_shipping) {
                                $cost = 0;

                            } elseif ($additional_charge){
                                                            $operator = get_option('iflow_additional_charge_operation', 'add');
                                                            if ($operator == 'sub') {
                                                                $sign = -1;
                                                            } else {
                                                                $sign = 1;
                                                            }

                                                            if (get_option('iflow_additional_charge_type', 'rel') == 'abs') {
                                                                // Cambio en valor absoluto
                                                                $cost = $cost + get_option('iflow_additional_charge', 0) * $sign;

                                                            } else {
                                                                // Cambio en valor relativo
                                                                $cost = $cost + $cost * get_option('iflow_additional_charge', 0)/100 * $sign;
                                                            }

                                $cost = max(0, $cost);
                              }

                            
                              // Armado de rates

                            $rate = array(
                                    'id' => 'iflow',
                                    'label' => 'Delivery Service iFLOW S.A.', 
                                    'cost' => $cost,
                                    'calc_tax' => 'per_order'
                                );
                                 
                            $this->add_rate($rate);
                            return;

  }


            public function get_products_from_cart()
            {
                $helper = new Helper();
                $products = $helper->get_items_from_cart();
                return $products;
            }

            private function localize_date(\DateTime $datetime, \DateInterval $diff_to_now)
            {

                $datetime = $datetime->setTimezone(new \DateTimeZone(wp_timezone_string()));

                if ($diff_to_now->days < 7) {
                    // Responder con fecha relativa o dia de semana
                    if ($diff_to_now->days < 1) {
                        return 'hoy';
                    } elseif ($diff_to_now->days > 1) {
                        return 'el '. __($datetime->format('l'));
                    } else {
                        return 'mañana';
                    }

                } else {
                    // Responder con la fecha exacta
                    return 'el '.$datetime->format('d').' de '.strtolower(__($datetime->format('F')));
                }


            }

            // ok

          }

        }



  }
 ?>
