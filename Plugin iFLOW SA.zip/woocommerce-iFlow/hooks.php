<?php

if (!defined('ABSPATH')) {
	exit;   // Exit if accessed directly.
}

// --- Settings
add_action('admin_init', 'iflow\iflow\Settings\init_settings');
add_action('admin_menu', 'iflow\iflow\Settings\create_menu_option');

// --- Method
add_action('woocommerce_shipping_init', 'iflow\iflow\iflow_init');
add_filter('woocommerce_shipping_methods', 'iflow\iflow\Utils\add_method');

// --- Checkout
add_action('woocommerce_checkout_update_order_meta', 'iflow\iflow\Utils\update_order_meta');
add_filter('woocommerce_cart_shipping_method_full_label', 'iflow\iflow\Utils\iflow_add_free_shipping_label', 10, 2);
add_filter('woocommerce_checkout_update_order_review', 'iflow\iflow\Utils\clear_cache');
add_action( 'woocommerce_flat_rate_shipping_add_rate', array( "30", 'calculate_extra_shipping' ), 10, 2 );

// --- Orders
//add_action('woocommerce_order_status_changed', 'iflow\iflow\Utils\process_order_status', 10, 3);
//add_action('add_meta_boxes', 'iflow\iflow\Utils\add_order_side_box');
//add_filter('woocommerce_admin_order_actions', 'iflow\iflow\Utils\add_action_button', 10, 2);
//add_action('admin_enqueue_scripts', 'iflow\iflow\Utils\add_button_css_file');


// --- Webhook
//add_action('woocommerce_api_iflow', 'iflow\iflow\Utils\handle_webhook');




// Compatibilidad con plugin Woocommerce Shipping Calculator On Product Page (Magerips)
add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_true');
