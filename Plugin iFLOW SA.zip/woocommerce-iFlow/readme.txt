=== Envios con iFLOW en Woocommerce ===
Contributors: Zeus Solutions
Donate link: https://www.iflow21.com
Tags: envios, iFLOW, argentina, shipping, woocommerce
Requires at least: 1.6
Tested up to: 1.4.2
Requires PHP: 7
Stable tag: 1.5
Language: Spanish
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Conecta tu tienda Woocommerce con iFLOW SA para realizar envíos a todo Argentina.

== Description ==
