<?php
/*
 * Plugin Name: Envíos con iFLOW SA para Woocommerce
 * Plugin URI: https://iflow21.com
 * Description: Integra WooCommerce con iFLOW SA para realizar envíos a todo el país.
 * Version: 1.2
 * Author: iFLOW SA
 * Author URI: https://www.iFLOW21.com/
 * Requires PHP: 7
 * License: GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * WC requires at least: 4.0.0
 * WC tested up to: 5.6.0
 * Text Domain: iFLOW_woocommerce
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('IFLOW_APIKEY', '');
define('IFLOW_SECRETKEY', '');
define('IFLOW_LOGGER_CONTEXT', serialize(array('source' => 'iflow')));
define('IFLOW_VERSION', '1.2');

require_once 'utils.php';
require_once 'iflow-method.php';
require_once 'iflow-settings.php';
require_once 'helper.php';
require_once 'hooks.php';

register_activation_hook(__FILE__, 'iflow\iflow\Utils\activate_plugin');

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'iflow\iflow\Utils\add_plugin_column_links');

add_filter('plugin_row_meta', 'Iflow\iflow\Utils\add_plugin_description_links', 10, 4);

add_filter('gettext', 'iflow_translate_words_array', 20, 3);
add_filter('ngettext', 'iflow_translate_words_array', 20, 3);

function iflow_translate_words_array($translation, $text, $domain)
{
    if ($text === 'Enter your address to view shipping options.') {
        $translation = 'Ingresá tu dirección para conocer los costos de envio';
    }
    return $translation;
}


 ?>
